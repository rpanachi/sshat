package org.stripesstuff.stripersist;

public interface StripersistInit
{
	public void init();
}
