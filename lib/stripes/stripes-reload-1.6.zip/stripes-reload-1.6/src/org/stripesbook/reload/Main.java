/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload;

/**
 * Contains a main() method that displays the plugin's title, version and web site. This class can
 * be executed simply by running {@code java -jar stripes-reload.jar}.
 *
 * @author Frederic Daoud
 */
public class Main {
    /** Displays the plugin's title, version and web site. */
    public static void main(String[] args) {
        Package pkg = Main.class.getPackage();
        String title = pkg.getImplementationTitle();
        String version = pkg.getImplementationVersion();
        String vendor = pkg.getImplementationVendor();

        System.out.println(title);
        System.out.println("Version " + version);
        System.out.println("For more information, visit " + vendor);
    }
}
