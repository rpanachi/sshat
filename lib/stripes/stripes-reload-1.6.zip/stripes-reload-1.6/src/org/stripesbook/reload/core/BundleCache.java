/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload.core;

import java.net.URL;
import java.util.Locale;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import net.sourceforge.stripes.util.Log;

/**
 * Resource cache for resource bundles. The resource key is a {@link BundleKey}, and the resource is
 * a {@link java.util.ResourceBundle}. This allows to reload the resource bundles used by Stripes,
 * which are {@code StripesResources_xx.properties} by default.
 *
 * @author Frederic Daoud
 */
public class BundleCache extends ResourceCache<BundleKey,ResourceBundle> {
    private static final Log log = Log.getInstance(BundleCache.class);

    /**
     * Creates a {@link java.util.PropertyResourceBundle} from the {@code .properties} file.
     */
    @Override
    public ResourceBundle reloadResource(BundleKey bundleKey) throws Exception {
        String fileName = getResourceFileName(bundleKey);
        URL url = getClass().getResource(fileName);
        return new PropertyResourceBundle(url.openStream());
    }
    /**
     * Constructs and returns the name of the {@code .properties} file using the resource bundle
     * base name and the {@link java.util.Locale}'s language, country, and variant, taking into
     * consideration that any of those three may be blank.
     */
    @Override
    protected String getResourceFileName(BundleKey bundleKey) {
        StringBuilder builder = new StringBuilder();
        builder.append('/').append(bundleKey.getBundleName());
        Locale locale = bundleKey.getLocale();
        if (locale != null) {
            builder.append('_').append(locale.getLanguage());
            builder.append('_').append(locale.getCountry());
            builder.append('_').append(locale.getVariant());

            // Any of language, country, or variant could be blank "", so remove any trailing '_'s
            int index;
            while (builder.charAt((index = builder.length() - 1)) == '_') {
                builder.deleteCharAt(index);
            }
        }
        int index;
        while (   (getClass().getResourceAsStream(builder.toString() + ".properties") == null)
               && ((index = builder.lastIndexOf("_")) != -1)
              )
        {
            builder.delete(index, builder.length());
        }
        String result = builder.append(".properties").toString();
        log.debug("Resource bundle file name: ", result);
        return result;
    }
}
