/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload.core;

import java.util.Locale;

/**
 * Represents a key for a {@link java.util.ResourceBundle}, consisting of the bundle's base name
 * and the {@link java.util.Locale}, and used by {@link BundleCache}.
 *
 * @author Frederic Daoud
 */
public class BundleKey {
    private String bundleName;
    private Locale locale;

    public BundleKey(String bundleName, Locale locale) {
        this.bundleName = bundleName;
        this.locale = locale;
    }
    public String getBundleName() {
        return bundleName;
    }
    public Locale getLocale() {
        return locale;
    }
    @Override
    public int hashCode() {
        StringBuilder builder = new StringBuilder(bundleName);
        if (locale != null) {
            builder.append('_').append(locale.getLanguage())
                   .append('_').append(locale.getCountry())
                   .append('_').append(locale.getVariant());
        }
        return builder.toString().hashCode();
    }
    @Override
    public boolean equals(Object object) {
        try {
            BundleKey key = (BundleKey) object;
            if (!key.getBundleName().equals(bundleName)) {
                return false;
            }
            if (key.getLocale() == null) {
                return (locale == null);
            }
            return key.getLocale().equals(locale);
        }
        catch (Exception exc) {
            return false;
        }
    }
    @Override
    public String toString() {
        return bundleName + " : " + locale;
    }
}
