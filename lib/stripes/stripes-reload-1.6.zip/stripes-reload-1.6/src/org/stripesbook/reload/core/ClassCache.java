/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload.core;

import net.sourceforge.stripes.util.Log;

import org.stripesbook.reload.util.Util;

/**
 * Resource cache for classes. The resource key is the class name, and the resource is the class.
 *
 * @author Frederic Daoud
 */
public class ClassCache extends ResourceCache<String,Class<?>> {
    private static final Log log = Log.getInstance(ClassCache.class); 

    @Override
    protected Class<?> reloadResource(String className) throws ClassNotFoundException {
        return new ReloadClassLoader().reloadClass(className);
    }
    @Override
    protected String getResourceFileName(String className) {
        return Util.convertToFileName(className);
    }
    /**
     * When adding a class, also add the parent classes that are loaded from files. Do not manage
     * classes that are loaded from JARs and WARs.
     */
    @Override
    public void add(String className, Class<?> cls) {
        super.add(className, cls);
        Class<?> parent = cls.getSuperclass();
        if (Util.isClassFromFile(parent)) {
            add(parent.getName(), parent);
        }
    }
    /**
     * If a class does not need to be reloaded, also check parent classes.
     */
    @Override
    public boolean needToReload(String className) {
        if (!Util.isClassFromFile(className)) {
            return false;
        }
        boolean result = super.needToReload(className);
        if (result == false) {
            Class<?> cls = getResourceFromCache(className);
            Class<?> parent = cls.getSuperclass();
            if (Util.isClassFromFile(parent)) {
                result = needToReload(parent.getName());
            }
        }
        log.debug("Need to reload class ", className, ": ", result);
        return result;
    }
    /**
     * Handle classes that are not managed by the cache.
     */
    @Override
    public Class<?> getResource(String className) throws Exception {
        return Util.isClassFromFile(className) ?
            super.getResource(className) : Class.forName(className);
    }
}
