/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload.core;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import org.stripesbook.reload.util.Util;

import net.sourceforge.stripes.action.ActionBean;
import net.sourceforge.stripes.exception.StripesRuntimeException;
import net.sourceforge.stripes.format.Formatter;
import net.sourceforge.stripes.util.Log;
import net.sourceforge.stripes.validation.TypeConverter;

/**
 * A class loader that reloads a given class. Typical use is
 * {@code new ReloadClassLoader().reloadClass("com.myco.pkg.ClassName");}.
 *
 * @author Frederic Daoud
 */
public class ReloadClassLoader extends ClassLoader {
    /** The buffer size used when loading a class file. */
    public static final int BUFFER_SIZE = 1024;

    private static final Log log = Log.getInstance(ReloadClassLoader.class);

    public ReloadClassLoader() {
        super(Thread.currentThread().getContextClassLoader());
    }
    @Override
    protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
        log.trace("loadClass(", name, ", ", resolve, ")");
        Class<?> cls = reloadClass(name);
        if (cls == null) {
            log.trace("Using system classloader");
            cls = super.loadClass(name, resolve);
        }
        else if (resolve) {
            resolveClass(cls);
        }
        return cls;
    }
    /**
     * Reloads the given class from the corresponding {@code .class} file found on the class path.
     *
     * @param className the fully qualified name of the class to be reloaded.
     * @return the reloaded {@link Class} instance.
     * @throws ClassNotFoundException thrown if the class could not be found.
     */
    public Class<?> reloadClass(String className) throws ClassNotFoundException {
        log.debug("Loading class: ", className);

        if (isClassManagedByReloader(className)) {
            URL url = getClass().getResource(getFileName(className));
            byte[] bytes = readBytes(url);
            if (bytes == null) {
                throw new StripesRuntimeException("Could not read bytes from " + url);
            }
            log.debug("Defining class: ", className);
            return defineClass(className, bytes, 0, bytes.length);
        }
        else {
            log.trace("Not reloading ", className, " because it is not managed by the reloader");
            return null;
        }
    }
    protected String getFileName(String className) {
        return Util.convertToFileName(className);
    }
    protected int getBufferSize() {
        return BUFFER_SIZE;
    }
    /**
     * Reads the bytes of an input stream and returns a byte array.
     */
    protected byte[] readBytes(URL url) {
        try {
            InputStream in = url.openStream();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[getBufferSize()];
            int length;
            while ((length = in.read(buffer)) > 0) {
                byteArrayOutputStream.write(buffer, 0, length);
            }
            return byteArrayOutputStream.toByteArray();
        }
        catch (IOException exc) {
            log.error(exc, "Could not read bytes from input stream");
            return null;
        }
    }
    /**
     * Checks if the reloader should manage the given class. All classes that don't come from
     * {@code .class} are immediately eliminated. But that's not enough; for example, we don't
     * want to reload model classes that are loaded by the class loader as a side effect of
     * reloading the TypeConverter for that model class.
     */
    protected boolean isClassManagedByReloader(String className) {
        if (!Util.isClassFromFile(className)) {
            return false;
        }
        try {
            Class<?> cls = Class.forName(className); 
            List<Class<?>> supportedInterfaces = getSupportedInterfaces();
            for (Class<?> c = cls; c != null; c = c.getSuperclass()) {
                for (Class<?> interf : c.getInterfaces()) {
                    if (supportedInterfaces.contains(interf)) {
                        return true;
                    }
                }
            }
            return false;
        }
        catch (Exception exc) {
            return false;
        }
    }
    /**
     * Returns the list of interfaces supported by this reload class loader.
     */
    protected List<Class<?>> getSupportedInterfaces() {
        return SUPPORTED_INTERFACES;
    }
    private static final List<Class<?>> SUPPORTED_INTERFACES = Arrays.asList(new Class<?>[] {
        ActionBean.class,
        Formatter.class,
        TypeConverter.class,
    });
}
