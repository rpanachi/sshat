/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload.core;

import java.io.File;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import net.sourceforge.stripes.util.Log;

/**
 * Caches resource instances with their last-modified timestamp, to determine the need to reload
 * them when they are updated.
 *
 * @author Frederic Daoud
 */
public abstract class ResourceCache<K,T> {
    private static final Log log = Log.getInstance(ResourceCache.class);

    private Map<K,ResourceInfo<T>> map = new HashMap<K,ResourceInfo<T>>();

    /** Method that subclasses must implement to reload a resource. */
    protected abstract T reloadResource(K resourceKey) throws Exception;

    /** Method that subclasses must implement to determine the file name for a resource. */
    protected abstract String getResourceFileName(K resourceKey);

    /**
     * Returns a resource according to the resource key, reloading the resource if it has been
     * updated since the last time it was loaded, or returning the previous resource otherwise.
     */
    public T getResource(K resourceKey) throws Exception {
        T resource = null;

        if (needToReload(resourceKey)) {
            log.info("Reloading ", resourceKey);
            resource = reloadResource(resourceKey);
            add(resourceKey, resource);
        }
        else {
            resource = map.get(resourceKey).getResource();
        }
        return resource;
    }
    /**
     * Gets a resource directly from the cache, without checking if it needs to be reloaded.
     */
    protected T getResourceFromCache(K resourceKey) {
        return map.get(resourceKey).getResource();
    }
    /**
     * Determines if a resource will need to be reloaded. This allows client code to take any
     * appropriate action knowing that {@link #getResource(Object)} will return a reloaded resource.
     */
    public boolean needToReload(K resourceKey) {
        ResourceInfo<T> info = map.get(resourceKey);
        boolean result = info == null || (getLastModified(resourceKey) > info.lastModified);
        log.debug("Need to reload resource ", resourceKey, ": ", result);
        return result;
    }
    /**
     * Adds a resource to the cache.
     */
    public void add(K resourceKey, T resource) {
        map.put(resourceKey, new ResourceInfo<T>(resource, getLastModified(resourceKey)));
    }
    /**
     * Determines the time stamp of the last time a resource was modified.
     */
    protected long getLastModified(K resourceKey) {
        URL url = getClass().getResource(getResourceFileName(resourceKey));

        // Try really hard to find the last modified timestamp, but don't throw any exceptions if
        // it doesn't work out.
        if (url != null) {
            File file = null;
            try { file = new File(url.toURI()); }
            catch (Exception exc) { }
            if (file == null) {
                try { file = new File(url.getPath()); }
                catch (Exception exc) { }
            }
            if (file != null) {
                return file.lastModified();
            }
        }
        return 0;
    }
    /**
     * Class for internal use, contains a resource and its last modified time.
     */
    private static class ResourceInfo<T> {
        private T resource;
        private long lastModified;

        public ResourceInfo(T resource, long lastModified) {
            this.resource = resource;
            this.lastModified = lastModified;
        }
        public T getResource() {
            return resource;
        }
        public long getLastModified() {
            return lastModified;
        }
    }
}
