/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload.extensions;

import java.util.Set;

import org.stripesbook.reload.core.ClassCache;
import net.sourceforge.stripes.action.ActionBean;
import net.sourceforge.stripes.action.ActionBeanContext;
import net.sourceforge.stripes.config.Configuration;
import net.sourceforge.stripes.controller.NameBasedActionResolver;
import net.sourceforge.stripes.exception.StripesServletException;
import net.sourceforge.stripes.util.Log;

/**
 * Action Resolver that reloads modified Action Beans and finds newly added Action Beans without
 * having to restart the server.
 *
 * @author Frederic Daoud
 */
public class ReloadActionResolver extends NameBasedActionResolver {
    private static final Log log = Log.getInstance(ReloadActionResolver.class);
    private ClassCache cache = new ClassCache();

    /**
     * Adds the initially loaded Action Beans to the class cache.
     */
    @Override
    public void init(Configuration config) throws Exception {
        super.init(config);
        for (Class<? extends ActionBean> cls : getActionBeanClasses()) {
            cache.add(cls.getName(), cls);
        }
        log.warn("########################################################################");
        log.warn("# Stripes-Reload                                                       #");
        log.warn("# Enjoy developing with Stripes!                                       #");
        log.warn("# Please don't forget to turn off Stripes-Reload in production.        #");
        log.warn("# For more info, see http://www.stripesbook.org/stripes-reload.html    #");
        log.warn("########################################################################");
    }
    /**
     * Reloads an Action Bean class if it has been modified since the last time the class was loaded.
     */
    @Override
    protected ActionBean makeNewActionBean(Class<? extends ActionBean> type, ActionBeanContext ctx)
        throws Exception
    {
        String className = type.getName();
        log.debug("makeNewActionBean: ", className);
        boolean reloaded = cache.needToReload(className);
        Class<?> cls = cache.getResource(className);
        ActionBean actionBean = (ActionBean) getConfiguration().getObjectFactory().newInstance(cls);
        if (reloaded) {
            addActionBean(actionBean.getClass());
        }
        return actionBean;
    }
    /**
     * Rescans for Action Beans if no Action Bean that matches the URL binding is found.
     */
    @Override
    public ActionBean getActionBean(ActionBeanContext context, String urlBinding)
        throws StripesServletException
    {
        log.debug("getActionBean: ", urlBinding);
        try {
            return super.getActionBean(context, urlBinding);
        }
        catch (StripesServletException exc) {
            rescanFor(urlBinding);
            return super.getActionBean(context, urlBinding);
        }
    }
    /**
     * Rescans for Action Beans if no Action Bean that matches the path is found.
     */
    @Override
    public Class<? extends ActionBean> getActionBeanType(String path) {
        log.debug("getActionBeanType for path: ", path);

        Class<? extends ActionBean> cls = super.getActionBeanType(path);
        if (cls == null && !path.endsWith(".jsp")) {
            cls = rescanFor(path);
        }
        return cls;
    }
    /**
     * Redoes the scan that Stripes normally does at startup to find Action Beans, and looks for an
     * Action Bean that is bound to the given URL.
     *
     * @param urlBinding the URL binding of the Action Bean.
     * @return the Action Bean that is bound to the URL, or {@code null} if none was found.
     */
    protected Class<? extends ActionBean> rescanFor(String urlBinding) {
        Set<Class<? extends ActionBean>> classes = findClasses();
        for (Class<? extends ActionBean> cls : classes) {
            if (urlBinding.equals(getUrlBinding(cls))) {
                addActionBean(cls);
                return cls;
            }
        }
        return null;
    }
}
