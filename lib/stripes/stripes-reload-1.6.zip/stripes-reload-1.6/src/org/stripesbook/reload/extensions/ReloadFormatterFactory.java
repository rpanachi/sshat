/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload.extensions;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Locale;

import org.stripesbook.reload.core.ClassCache;

import net.sourceforge.stripes.config.TargetTypes;
import net.sourceforge.stripes.format.DefaultFormatterFactory;
import net.sourceforge.stripes.format.Formatter;
import net.sourceforge.stripes.format.ObjectFormatter;
import net.sourceforge.stripes.util.Log;
import net.sourceforge.stripes.util.ReflectUtil;

/**
 * Formatter Factory that reloads modified Formatters and finds newly added Formatters without
 * having to restart the server.
 *
 * @author Frederic Daoud
 */
public class ReloadFormatterFactory extends DefaultFormatterFactory {
    private static final Log log = Log.getInstance(ReloadFormatterFactory.class);
    private ClassCache cache = new ClassCache();

    /**
     * When a Formatter is added to the factory, its Class is added to the cache.
     */
    @Override
    public void add(Class<?> targetType, Class<? extends Formatter<?>> formatterClass) {
        super.add(targetType, formatterClass);
        log.debug("Adding formatter ", formatterClass, " to format ", targetType);
        cache.add(formatterClass.getName(), formatterClass);
    }
    /**
     * When looking for a Formatter, rescans the extension packages when a Formatter is not found
     * for the target class. Also, when a Formatter is found, its class is checked to see if it
     * needs to be reloaded.
     */
    @Override
    @SuppressWarnings("unchecked")
    protected Class<? extends Formatter<?>> findFormatterClass(Class<?> targetClass) {
        log.debug("findFormatterClass: ", targetClass);

        Class<? extends Formatter<?>> formatterClass = super.findFormatterClass(targetClass);

        if (formatterClass == null || formatterClass.equals(ObjectFormatter.class)) {
            log.debug("Rescanning for formatters");

            List<Class<? extends Formatter>> formatters =
                getConfiguration().getBootstrapPropertyResolver().getClassPropertyList(Formatter.class);

            for (Class<? extends Formatter> formatter : formatters) {
                Type[] typeArguments = ReflectUtil.getActualTypeArguments(formatter, Formatter.class);
                if ((typeArguments != null) && (typeArguments.length == 1)
                        && typeArguments[0].equals(targetClass)) {
                    formatterClass = (Class<? extends Formatter<?>>) formatter;
                }
                else {
                    TargetTypes targetTypes = formatter.getAnnotation(TargetTypes.class);
                    if (targetTypes != null) {
                        for (Class<?> targetType : targetTypes.value()) {
                            if (targetType.equals(targetClass)) {
                                formatterClass = (Class<? extends Formatter<?>>) formatter;
                                break;
                            }
                        }
                    }
                }
            }
            if (formatterClass == null || formatterClass.equals(ObjectFormatter.class)) {
                log.debug("Still no formatter found");
                return null;
            }
            add(targetClass, formatterClass);
        }
        String className = formatterClass.getName();
        boolean reloaded = cache.needToReload(className);
        try {
            formatterClass = (Class<? extends Formatter<?>>) cache.getResource(className);
            if (reloaded) {
                super.add(targetClass, formatterClass);
            }
        }
        catch (Exception exc) {
            log.error(exc);
        }
        return formatterClass;
    }
    /**
     * Reloads the Formatter class if it has been modified since the last time it was loaded.
     */
    @Override
    @SuppressWarnings("unchecked")
    public Formatter<?> getInstance(Class<? extends Formatter<?>> cls, String formatType,
        String formatPattern, Locale locale)
        throws Exception
    {
        log.debug("getInstance of formatter: ", cls);

        cls = (Class<? extends Formatter<?>>) cache.getResource(cls.getName());
        return super.getInstance(cls, formatType, formatPattern, locale);
    }
}

