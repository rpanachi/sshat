/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload.extensions;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.jstl.core.Config;
import javax.servlet.jsp.jstl.fmt.LocalizationContext;

import org.stripesbook.reload.core.BundleCache;
import org.stripesbook.reload.core.BundleKey;

import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.config.ConfigurableComponent;
import net.sourceforge.stripes.config.Configuration;
import net.sourceforge.stripes.controller.ExecutionContext;
import net.sourceforge.stripes.controller.Interceptor;
import net.sourceforge.stripes.controller.Intercepts;
import net.sourceforge.stripes.controller.LifecycleStage;
import net.sourceforge.stripes.util.Log;

/**
 * Reloads the JSTL localization resource bundles if it has been modified since the last time that
 * it was loaded.
 *
 * @author Frederic Daoud
 */
@Intercepts(LifecycleStage.ResolutionExecution)
public class ReloadJstlBundleInterceptor implements Interceptor, ConfigurableComponent {
    private static final Log log = Log.getInstance(ReloadJstlBundleInterceptor.class);

    private BundleCache cache = new BundleCache();
    private String bundleName;

    public void init(Configuration config) throws Exception {
        String configuredBundleName =
            config.getServletContext().getInitParameter(Config.FMT_LOCALIZATION_CONTEXT);

        if (configuredBundleName != null) {
            bundleName = configuredBundleName.replace('.', '/');
            log.debug("JSTL bundle name: ", bundleName);
        }
    }

    public Resolution intercept(ExecutionContext execContext) throws Exception {
        if (bundleName != null) {
            HttpServletRequest request = execContext.getActionBeanContext().getRequest();
            Locale locale = request.getLocale();
            ResourceBundle bundle = cache.getResource(new BundleKey(bundleName, locale));
            try {
                LocalizationContext localizationContext = new LocalizationContext(bundle, locale);
                Config.set(request, Config.FMT_LOCALIZATION_CONTEXT, localizationContext);
            }
            catch (NoClassDefFoundError err) {
                // Do not depend on JSTL being present
            }
        }
        return execContext.proceed();
    }
}
