/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload.extensions;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.stripesbook.reload.core.BundleCache;
import org.stripesbook.reload.core.BundleKey;

import net.sourceforge.stripes.config.Configuration;
import net.sourceforge.stripes.exception.StripesRuntimeException;
import net.sourceforge.stripes.localization.DefaultLocalizationBundleFactory;

/**
 * Reloads the error message and field name resource bundles if they have been modified since the
 * last time that they were loaded.
 *
 * @author Frederic Daoud
 */
public class ReloadLocalizationBundleFactory extends DefaultLocalizationBundleFactory {
    private String errorBundleName, fieldBundleName;
    private BundleCache cache = new BundleCache();

    /**
     * It is unfortunate to have to duplicate this code. It would not be necessary if only
     * DefaultLocalizationBundleFactory made errorBundleName and fieldBundleName accessible to
     * subclasses.
     */
    @Override
    public void init(Configuration configuration) {
        errorBundleName = configuration.getBootstrapPropertyResolver()
            .getProperty(ERROR_MESSAGE_BUNDLE);
        if (errorBundleName == null) {
            errorBundleName = BUNDLE_NAME;
        }
        errorBundleName = errorBundleName.replace('.', '/');

        fieldBundleName = configuration.getBootstrapPropertyResolver()
            .getProperty(FIELD_NAME_BUNDLE);
        if (fieldBundleName == null) {
            fieldBundleName = BUNDLE_NAME;
        }
        fieldBundleName = fieldBundleName.replace('.', '/');
    }
    /**
     * Reloads the error message bundle if it has been modified since the last time it was loaded.
     */
    @Override
    public ResourceBundle getErrorMessageBundle(Locale locale) throws MissingResourceException {
        try {
            return cache.getResource(new BundleKey(errorBundleName, locale));
        }
        catch (Exception exc) {
            throw new StripesRuntimeException(exc);
        }
    }
    /**
     * Reloads the form field name bundle if it has been modified since the last time it was loaded.
     */
    @Override
    public ResourceBundle getFormFieldBundle(Locale locale) throws MissingResourceException {
        try {
            return cache.getResource(new BundleKey(fieldBundleName, locale));
        }
        catch (Exception exc) {
            throw new StripesRuntimeException(exc);
        }
    }
}
