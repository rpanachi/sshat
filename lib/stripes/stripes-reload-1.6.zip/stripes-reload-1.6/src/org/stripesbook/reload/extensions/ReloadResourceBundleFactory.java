/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload.extensions;

import java.util.Locale;
import java.util.ResourceBundle;
import net.sourceforge.stripes.config.Configuration;
import org.stripesbook.reload.core.BundleCache;
import org.stripesbook.reload.core.BundleKey;
import org.stripesstuff.plugin.localization.DefaultResourceBundleFactory;

/**
 * Reloads the message resource bundle from the <a href="http://www.stripes-stuff.org">Stripes-Stuff</a>
 * localization plugin, if it has been modified since the last time that they were loaded. If
 * Stripes-Stuff is not present, a warning will be issued and the extension will not be loaded, but
 * otherwise, no harm done.
 *
 * @author Frederic Daoud
 */
public class ReloadResourceBundleFactory extends DefaultResourceBundleFactory {
    private BundleCache cache = new BundleCache();
    private String pathName;

    @Override
    public void init(Configuration configuration) throws Exception {
        super.init(configuration);
        pathName = getBaseName().replace('.', '/');
    }

    @Override
    public ResourceBundle getDefaultBundle(Locale locale) {
        try {
            return cache.getResource(new BundleKey(pathName, locale));
        }
        catch (Exception exc) {
            throw new RuntimeException(exc);
        }
    }
}
