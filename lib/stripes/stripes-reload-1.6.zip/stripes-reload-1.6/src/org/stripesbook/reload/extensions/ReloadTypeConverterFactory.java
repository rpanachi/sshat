/*
 * Copyright (c) 2008 Frederic Daoud
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.stripesbook.reload.extensions;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Locale;

import org.stripesbook.reload.core.ClassCache;

import net.sourceforge.stripes.config.TargetTypes;
import net.sourceforge.stripes.util.Log;
import net.sourceforge.stripes.util.ReflectUtil;
import net.sourceforge.stripes.validation.DefaultTypeConverterFactory;
import net.sourceforge.stripes.validation.TypeConverter;

/**
 * Type Converter Factory that reloads modified Type Converters and finds newly added Type Converters
 * without having to restart the server.
 *
 * @author Frederic Daoud
 */
public class ReloadTypeConverterFactory extends DefaultTypeConverterFactory {
    private static final Log log = Log.getInstance(ReloadTypeConverterFactory.class);
    private ClassCache cache = new ClassCache();

    /**
     * When a Type Converter is added to the factory, its Class is added to the cache.
     */
    @Override
    public void add(Class<?> targetType, Class<? extends TypeConverter<?>> converterClass) {
        super.add(targetType, converterClass);
        log.debug("Adding type converter ", converterClass, " to convert ", targetType);
        cache.add(converterClass.getName(), converterClass);
    }
    /**
     * When looking for a Type Converter, rescans the extension packages when a Type Converter is
     * not found for the target class. Also, when a Type Converter is found, its class is checked to
     * see if it needs to be reloaded.
     */
    @Override
    @SuppressWarnings("unchecked")
    protected Class<? extends TypeConverter<?>> findTypeConverterClass(Class<?> targetClass) {
        log.debug("findTypeConverterClass: ", targetClass);

        Class<? extends TypeConverter<?>> converterClass = super.findTypeConverterClass(targetClass);

        if (converterClass == null) {
            log.debug("Rescanning for type converters");

            List<Class<? extends TypeConverter>> typeConverters =
                getConfiguration().getBootstrapPropertyResolver().getClassPropertyList(TypeConverter.class);

            for (Class<? extends TypeConverter> typeConverter : typeConverters) {
                Type[] typeArguments = ReflectUtil.getActualTypeArguments(typeConverter, TypeConverter.class);
                if ((typeArguments != null) && (typeArguments.length == 1)
                        && typeArguments[0].equals(targetClass)) {
                    converterClass = (Class<? extends TypeConverter<?>>) typeConverter;
                }
                else {
                    TargetTypes targetTypes = typeConverter.getAnnotation(TargetTypes.class);
                    if (targetTypes != null) {
                        for (Class<?> targetType : targetTypes.value()) {
                            if (targetType.equals(targetClass)) {
                                converterClass = (Class<? extends TypeConverter<?>>) typeConverter;
                                break;
                            }
                        }
                    }
                }
            }
            if (converterClass == null) {
                log.debug("Still no type converter found");
                return null;
            }
            add(targetClass, converterClass);
        }
        String className = converterClass.getName();
        boolean reloaded = cache.needToReload(className);
        try {
            converterClass = (Class<? extends TypeConverter<?>>) cache.getResource(className);
            if (reloaded) {
                super.add(targetClass, converterClass);
            }
        }
        catch (Exception exc) {
            log.error(exc);
        }
        return converterClass;
    }
    /**
     * Reloads the Type Converter class if it has been modified since the last time it was loaded.
     */
    @Override
    @SuppressWarnings("unchecked")
    public TypeConverter getInstance(Class<? extends TypeConverter> cls, Locale locale) throws Exception {
        log.debug("getInstance of type converter: ", cls);

        cls = (Class<? extends TypeConverter<?>>) cache.getResource(cls.getName());
        return super.getInstance(cls, locale);
    }
}
