package org.stripesbook.reload.util;

import java.net.URL;

/**
 * Utility methods.
 *
 * @author Frederic Daoud
 */
public final class Util {
    public static boolean isClassFromFile(Class<?> cls) {
        return (cls != null && isClassFromFile(cls.getName()));
    }
    /**
     * Determines if a class is from a {@code .class} file, as opposed to a JAR or WAR.
     */
    public static boolean isClassFromFile(String className) {
        URL url = Util.class.getResource(convertToFileName(className));
        return "file".equalsIgnoreCase(url.getProtocol());
    }
    /**
     * Converts a fully qualified class name to a file name.
     */
    public static String convertToFileName(String className) {
        return "/" + className.replace('.', '/') + ".class";
    }
}
