Stripes Stuff: Spring Object Factory

The SpringObjectFactory is an implementation of the Stripes ObjectFactory
interface (introduced in Stripes 1.6). It uses Spring to instantiate Stripes
ActionBeans and Interceptors.

Why do this?

We already have the Stripes @SpringBean annotation which retrieves Spring beans
by name or type. However, the ActionBeans themselves are not Spring beans. By
instantiating ActionBeans and Interceptors via Spring, they become actual Spring
beans and gain access to Spring services such as annotation-driven transactions
and security.

How does it work?

The SpringObjectFactory hooks into Stripe's ObjectFactory facility, and
dynamically registers ActionBeans and Interceptors as Spring Beans in the
configured Spring WebApplicationContext.

Gotchas:

* Dependency Injection
Since my motivation was to use Spring transactions and security on ActionBeans,
I haven't tested dependency injection yet. The Stripes @SpringBean annotation
'should' work fine. I expect that the Spring @Autowired annotation 'should' also
work for injecting dependencies into ActionBeans and Interceptors.
If you're using Spring autowiring, I recommend that you avoid marking any
Stripes classes with the Spring @Component stereotype annotations (or their
descendants). Consider setting up your Spring component-scanning to exclude the
packages that contain your Stripes ActionBeans and Interceptors.

Warning: The Stripes @SpringBean documentation warns about the risks of having
public getter/setter methods for Spring bean dependencies on ActionBeans. See
http://stripesframework.org/display/stripes/Spring+with+Stripes. The same
applies here. To mitigate this risk, you can 1) use the Stripes @SpringBean
annotation per the recommendations in the warning section in its documentation
OR 2) Use the Stripes StrictBinding feature appropriately.

* CGLib Proxies
Since Stripes ActionBeans don't require an interface, it is necessary to use
CGLib proxies. CGLib proxies have some limitations: they cannot proxy methods
marked as final, and the proxied class must have a zero-arg default constructor.

* WebApplicationContext
Like the Stripes @SpringBean annotation, SpringObjectFactory requires you to set
up a Spring WebApplicationContext in web.xml. SpringObjectFactory additionally
requires that the Spring WebApplicationContext also implements the Spring
BeanDefinitionRegistry interface. Spring's default implementation does not, so
this project provides one: StripesWebApplicationContext. This needs to be
explicitly named in web.xml (See setup instructions below).

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Setup
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Dependencies:
* Requires Stripes version >= 1.6
* Requires Spring version >= 2.5
* Requires CGLib and its dependencies, including AspectJ (these may be already
  available in your Spring distribution)

1. Configure the StripesWebApplicationContext
Within web.xml:
    <listener>
        <listener-class>
            org.springframework.web.context.ContextLoaderListener
        </listener-class>
    </listener>
    <context-param>
        <param-name>contextConfigLocation</param-name>
        <param-value>/WEB-INF/spring-context.xml</param-value>
    </context-param>
    <context-param>
        <param-name>contextClass</param-name>
        <param-value>
            org.stripesstuff.spring.context.StripesWebApplicationContext
        </param-value>
    </context-param>

2. Configure the SpringObjectFactory and its infrastructure.
This is done via Stripes extension packages facility. In web.xml, add the
following init-param to the configuration for the StripesFilter (or just add the
package "org.stripesstuff.spring" to your existing list of extension packages:

    <init-param>
        <param-name>Extension.Packages</param-name>
        <param-value>org.stripesstuff.spring</param-value>
    </init-param>

3. Add the stripes-stuff-spring.jar to your classpath, and make sure its bundled
with your web application at deploy time.

4. Tell Spring to use CGLib proxies
Within your Spring application context XML add the configuration:

    <aop:config proxy-target-class="true"/>

5. Logging: View debug log messages by adding the following to your
log4j.properties file: 

    log4j.logger.org.stripesstuff.spring=DEBUG












